﻿namespace Nezmatematika.ViewModel
{
    public class UserTypeSelectVM
    {

    }
}
