﻿namespace Nezmatematika.Model
{
    public static class GlobalValues
    {
        public const string CourseFilename = "Course.xml";
        public const string UserSettingsFilename = "Settings.xml";
    }
}
