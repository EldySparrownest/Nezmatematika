﻿namespace Nezmatematika.Model
{
    public enum PublishingStatus
    {
        NotPublished = 0,
        ChangesSincePublished = 1,
        PublishedUpToDate = 2
    }
}
